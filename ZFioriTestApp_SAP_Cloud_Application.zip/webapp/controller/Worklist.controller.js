/*global location history */
sap.ui.define([
	"ZFioriTestApp/ZFioriTestApp/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"ZFioriTestApp/ZFioriTestApp/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
	"use strict";
	return BaseController.extend("ZFioriTestApp.ZFioriTestApp.controller.Worklist", {
		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */
		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var oViewModel, iOriginalBusyDelay, oTable = this.byId("table");
			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			// keeps the search state
			this._aTableSearchState = [];
			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("saveAsTileTitle", this.getResourceBundle().getText("worklistViewTitle")),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function () {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
			// Add the worklist page to the flp routing history
			this.addHistoryEntry({
				title: this.getResourceBundle().getText("worklistViewTitle"),
				icon: "sap-icon://table-view",
				intent: "#ZFioriTestApp-display"
			}, true);
		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function (oEvent) {
			// update the worklist's object counter after the table update
			var sTitle, oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},
		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function (oEvent) {
			this._showObject(oEvent.getSource());
		},
		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function () {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},
		onSearch: function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");
				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("CompanyName", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}
		},
		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function () {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},
		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */
		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function (oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("CustomerID")
			});
		},
		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */
		_applySearch: function (aTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(aTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		},
		/**
		 *@memberOf ZFioriTestApp.ZFioriTestApp.controller.Worklist
		 */
		action: function (oEvent) {
			var that = this;
			var actionParameters = JSON.parse(oEvent.getSource().data("wiring").replace(/'/g, "\""));
			var eventType = oEvent.getId();
			var aTargets = actionParameters[eventType].targets || [];
			aTargets.forEach(function (oTarget) {
				var oControl = that.byId(oTarget.id);
				if (oControl) {
					var oParams = {};
					for (var prop in oTarget.parameters) {
						oParams[prop] = oEvent.getParameter(oTarget.parameters[prop]);
					}
					oControl[oTarget.action](oParams);
				}
			});
			var oNavigation = actionParameters[eventType].navigation;
			if (oNavigation) {
				var oParams = {};
				(oNavigation.keys || []).forEach(function (prop) {
					oParams[prop.name] = encodeURIComponent(JSON.stringify({
						value: oEvent.getSource().getBindingContext(oNavigation.model).getProperty(prop.name),
						type: prop.type
					}));
				});
				if (Object.getOwnPropertyNames(oParams).length !== 0) {
					this.getOwnerComponent().getRouter().navTo(oNavigation.routeName, oParams);
				} else {
					this.getOwnerComponent().getRouter().navTo(oNavigation.routeName);
				}
			}
		},
		/**
		 *@memberOf ZFioriTestApp.ZFioriTestApp.controller.Worklist
		 */
		onclick: function (oEvent) {
			win = window.open("https://google.com", name, "width=500,height=500");
		},
		/**
		 *@memberOf ZFioriTestApp.ZFioriTestApp.controller.Worklist
		 */
		onclick3: function (oEvent) {
			//берем числовое значение поля Input с идентификатором input0
			var inputNumber = this.getView().byId("input0").getValue();
			
			//можно вводить числа в формате 00*, ввод текста заблокориван свойством Type поля формы
			inputNumber = Number(inputNumber);
			
				//находим факториал взятого числа
				var initialFactorial = 1;
				for (var i = 1; i <= inputNumber; i++) {
				  initialFactorial *= i;
				}
				
				var fact = initialFactorial;
				
				//подсчет нулей
				var countOfZeros = 0;
				for (var m = 0; m <= initialFactorial; m++) {
				  if (fact % 10 !== 0) break;
				  else {
				    fact /= 10;
				    countOfZeros += 1;
				  }
				}
				
				sap.m.MessageBox.success("Число нулей на конце равно " + countOfZeros);
				sap.m.MessageBox.information("Факториал числа равен " + initialFactorial);
		},
		/**
		 *@memberOf ZFioriTestApp.ZFioriTestApp.controller.Worklist
		 */
		onclick4: function (oEvent) {
			// пользователь вводит номера двух версий
			var version1 = this.getView().byId("input1").getValue();
			var version2 = this.getView().byId("input2").getValue();
			
			//переводим данные из строк в массивы
			var array1 = version1.split(".");
			var array2 = version2.split(".");
			
			//переводим данные каждого из 4-х разрядов в числовые значения для каждого массива
			//вместо array1.length можно использовать 4, т.к. стандартная длина каждого массива = 4
			for (var i = 0; i < array1.length; i++) {
			  array1[i] = Number(array1[i]);
			  array2[i] = Number(array2[i]);
			}
			
			/*выбор более новой версии осуществляется путем сравнения числовых значений массивов
			последовательно по каждому из 4 разрядов слева на право (по старшинству)
			массив с большим числом в старшем разряде соответствует более новой версии*/
			for (i = 0; i <= array2.length; i++) {
			  if (array1[i] > array2[i]) {
			    sap.m.MessageBox.success("Первая версия более новая");
			    break;
			  }
			  else if (array1[i] < array2[i]) {
			    sap.m.MessageBox.success("Вторая версия более новая");
			    break;
			  }
			  else {
			  }
			}
		},
		/**
		 *@memberOf ZFioriTestApp.ZFioriTestApp.controller.Worklist
		 */
		zerosInFactorial: function (oEvent) {},
		/**
		 *@memberOf ZFioriTestApp.ZFioriTestApp.controller.Worklist
		 */
		onEnter: function (oEvent) {
			//берем числовое значение поля Input с идентификатором input0
			var inputNumber = this.getView().byId("input0").getValue();
			
			//можно вводить числа в формате 00*, ввод текста заблокориван свойством Type поля формы
			inputNumber = Number(inputNumber);
			
				//находим факториал взятого числа
				var initialFactorial = 1;
				for (var i = 1; i <= inputNumber; i++) {
				  initialFactorial *= i;
				}
				
				var fact = initialFactorial;
				
				//подсчет нулей
				var countOfZeros = 0;
				for (var m = 0; m <= initialFactorial; m++) {
				  if (fact % 10 !== 0) break;
				  else {
				    fact /= 10;
				    countOfZeros += 1;
				  }
				}
				
				sap.m.MessageBox.success("Число нулей на конце равно " + countOfZeros);
				sap.m.MessageBox.information("Факториал числа равен " + initialFactorial);
		}
	});
});